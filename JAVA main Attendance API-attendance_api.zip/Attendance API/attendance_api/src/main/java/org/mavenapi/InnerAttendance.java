package org.mavenapi;

public class InnerAttendance {

    public void setPresent(boolean isPresent) {
    }

    public void setDate(String date) {
    }

}
