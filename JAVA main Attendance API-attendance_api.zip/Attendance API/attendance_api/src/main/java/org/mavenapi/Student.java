// package org.mavenapi;

// import java.util.List;

// public class Student {

//     public Student(int id, String name, String email, String address, String contactNumber) {
//     }

//     public void setID(int id) {
//     }

//     public void setAttendance(List<Attendance> attendanceList) {
//     }

//     public void setName(String name) {
//     }

// }
